☆☆☆SalesUploderつかいかた☆☆☆

salesuploader.exe を実行すると、U-NEXT,FANZA,MGSの売上報告を受け取り、Googleスプレッドシートにかきこみます。動作にはGoogle Chromeが必要です。
また、chromedriverが同梱されていますが、これがGoogle Chromeのバージョンと合っている必要があります。アップデート方法などはほかのサイトを参照してください。
定期的に動作させるには、Windowsの機能であるタスクスケジューラなどを使ってください。


☆☆☆コンフィグ☆☆☆

salesuploader.dll.configをテキストエディタなどで編集すると、設定を変更できます。IDやパスワード、書き込み先などを変更できます。
なお、salesuploader.dll.config以外のconfigと名付けられたファイルはすべて無関係ですので、設定を変更しないようお願いします。


☆☆☆パッチノート☆☆☆
v1.0 初リリース
v1.1 chromedriverのバージョン違いの時エラーメッセージを出すように